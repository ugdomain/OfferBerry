class PaymentModel {
  String _name;
  double _amount;
  PaymentModel(this._name, this._amount);

  String get name => _name;
  double get amount => _amount;
}