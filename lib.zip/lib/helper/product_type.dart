enum ProductType {
  POPULAR_PRODUCT,
}